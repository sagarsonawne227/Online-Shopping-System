<!-- footer.php -->
<footer>
    <p>&copy; 2023 E-commerce Store. All rights reserved.</p>
</footer>
