-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 22, 2025 at 11:35 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `items` text NOT NULL,
  `total` int(11) NOT NULL,
  `payment_method` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `order_date`, `items`, `total`, `payment_method`) VALUES
(1, '2025-07-26 15:03:29', 'Wireless Headphones × 1 = ₹1499', 1499, NULL),
(2, '2025-07-26 15:04:15', 'Stylish T-shirt × 2 = ₹998', 998, NULL),
(3, '2025-07-26 15:12:23', 'Stylish T-shirt × 1 = ₹499', 499, NULL),
(4, '2025-07-26 15:15:48', 'Stylish T-shirt × 1 = ₹499', 499, NULL),
(5, '2025-07-26 15:17:47', 'Sports Cap × 2 = ₹598', 598, NULL),
(6, '2025-07-26 15:27:26', 'Stylish T-shirt × 1 = ₹499', 499, NULL),
(7, '2025-07-26 15:27:51', 'Stylish T-shirt × 1 = ₹499', 499, NULL),
(8, '2025-07-26 15:29:36', 'Stylish T-shirt × 1 = ₹499', 499, NULL),
(9, '2025-07-26 15:30:32', 'Wireless Headphones × 1 = ₹1499', 1499, NULL),
(10, '2025-07-26 15:54:01', 'Casual Hoodie × 1 = ₹999\nStylish T-shirt × 2 = ₹998', 1997, NULL),
(11, '2025-07-26 16:02:52', 'Stylish T-shirt × 1 = ₹499', 499, NULL),
(12, '2025-07-26 16:03:15', 'Wireless Headphones × 2 = ₹2998', 2998, NULL),
(13, '2025-07-26 16:24:44', 'Stylish T-shirt × 2 = ₹998\nWireless Headphones × 1 = ₹1499', 2497, NULL),
(14, '2025-07-26 16:29:57', 'Stylish T-shirt × 1 = ₹499', 499, NULL),
(15, '2025-07-26 16:35:54', 'Wireless Headphones × 1 = ₹1499\nGaming Mouse × 1 = ₹699', 2198, NULL),
(16, '2025-07-26 16:55:36', 'Laptop Stand × 21 = ₹14679', 14679, NULL),
(17, '2025-07-26 17:09:52', 'Casual Hoodie × 2 = ₹1998', 1998, NULL),
(18, '2025-07-26 17:13:19', 'Wireless Headphones × 2 = ₹2998', 2998, NULL),
(19, '2025-07-26 17:15:47', 'Denim Jacket × 2 = ₹3198', 3198, NULL),
(20, '2025-07-26 17:41:55', 'Wireless Headphones × 1 = ₹1499', 1499, NULL),
(21, '2025-09-16 03:24:00', 'Stylish T-shirt × 3 = ₹1497', 1497, NULL),
(22, '2025-09-16 11:24:09', 'Casual Hoodie × 2 = ₹1998', 1998, NULL),
(23, '2025-09-22 09:33:51', 'Wireless Headphones × 1 = ₹1499', 1499, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `rating` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `image`, `description`, `price`, `rating`) VALUES
(1, 'Stylish T-shirt', 'image/product1.jpeg', 'Comfortable cotton t-shirt perfect for daily wear.', 499.00, 4),
(2, 'Wireless Headphones', 'image/product2.jpeg', 'Bluetooth headphones with noise cancellation.', 1499.00, 5),
(3, 'Casual Hoodie', 'image/product3.jpg', 'Warm fleece hoodie for winter outings.', 999.00, 4),
(4, 'Denim Jacket', 'image/product4.jpg', 'Trendy denim jacket for casual look.', 1599.00, 5),
(5, 'Track Pants', 'image/product5.jpg', 'Stretchable pants ideal for gym or casual wear.', 799.00, 4),
(6, 'Stylish T-shirt', 'image/product1.jpeg', 'Comfortable cotton t-shirt perfect for daily wear.', 499.00, 4),
(7, 'Wireless Headphones', 'image/product2.jpeg', 'Bluetooth headphones with noise cancellation.', 1499.00, 5),
(8, 'Casual Hoodie', 'image/product3.jpg', 'Warm fleece hoodie for winter outings.', 999.00, 4),
(9, 'Denim Jacket', 'image/product4.jpg', 'Trendy denim jacket for casual look.', 1599.00, 5),
(10, 'Track Pants', 'image/product5.jpg', 'Stretchable pants ideal for gym or casual wear.', 799.00, 4),
(11, 'Sports Cap', 'image/product6.jpg', 'Breathable cap with adjustable strap.', 299.00, 3),
(12, 'Analog Watch', 'image/product7.jpg', 'Elegant watch with leather strap.', 1199.00, 4),
(13, 'Leather Wallet', 'image/product8.jpg', 'Compact and stylish genuine leather wallet.', 499.00, 4),
(14, 'Backpack', 'image/product9.jpg', 'Spacious and durable backpack for daily use.', 1099.00, 5),
(15, 'Running Shoes', 'image/product10.jpg', 'Lightweight and breathable running shoes.', 1899.00, 5),
(16, 'Formal Shirt', 'image/product11.jpg', 'Full-sleeve formal shirt for office wear.', 899.00, 4),
(17, 'Sunglasses', 'image/product12.jpg', 'UV-protected stylish sunglasses.', 499.00, 3),
(18, 'Smartphone', 'image/product13.jpg', 'Latest Android phone with fast charging.', 15999.00, 5),
(19, 'Power Bank', 'image/product14.jpg', '10000mAh power bank with dual output.', 899.00, 4),
(20, 'Bluetooth Speaker', 'image/product15.jpg', 'Portable speaker with deep bass.', 1199.00, 4),
(21, 'Gym Bag', 'image/product16.jpg', 'Spacious duffel for gym and travel.', 799.00, 4),
(22, 'Water Bottle', 'image/product17.jpg', 'Leak-proof stainless steel bottle.', 349.00, 3),
(23, 'Gaming Mouse', 'image/product18.jpg', 'RGB mouse with adjustable DPI.', 699.00, 5),
(24, 'Office Chair', 'image/product19.jpg', 'Ergonomic chair with lumbar support.', 4599.00, 5),
(25, 'Laptop Stand', 'image/product20.jpg', 'Adjustable stand for better posture.', 699.00, 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
